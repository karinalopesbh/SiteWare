﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SW.Models;

namespace SW.Controllers
{
    public class HomeController : Controller
    {

        /// <summary>
        /// Login
        /// </summary>
        /// <returns></returns>
        public ActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// Action da página principal
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public ActionResult Principal(Principal model)
        {
            int totalprodutos = 0;
            totalprodutos = model.TotalProdutos();
            ViewBag.Title = totalprodutos + " produtos encontrados";

            ProdutosObj produtoobj = new ProdutosObj();
            var modelProduto = produtoobj.ListaProdutos();

            return View(modelProduto);
        }

        /// <summary>
        /// Action com os detalhes do produto
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetalhesDoProduto(int id)
        {
            Produtos produto = new Produtos().GetProduto(id);
            ViewBag.Title = produto.Nome;
            var model = produto;
            return View(model);
        }

        /// <summary>
        /// Action ao chamar o carrinho de compras
        /// </summary>
        /// <returns></returns>
        public ActionResult CarrinhoCompra()
        {
            HttpCookie cookie = Request.Cookies["CookieCarrinhoLojaKarina"];
            string valorCookie = string.Empty;

            if (cookie != null)
            {
                valorCookie = cookie.Value;
            }

            CarrinhoCompraObject carrinhoCompraObj = new CarrinhoCompraObject();
            var modelCarinhoCompra = carrinhoCompraObj.ListaCarrinho(valorCookie);

            CarrinhoCompra carrinhoCompra = new Models.CarrinhoCompra();
            ViewBag.Total = carrinhoCompra.CalculaTotal(modelCarinhoCompra);
            return View(modelCarinhoCompra);
        }

        /// <summary>
        /// Action do Carrinho de compra ao adicionar um produto no carrinho
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CarrinhoCompra(Produtos model)
        {
            HttpCookie cookie = Request.Cookies["CookieCarrinhoLojaKarina"];

            if (cookie != null)
            {
                //cookie.Value = String.Concat(cookie.Value, model.IdProduto + "," + model.Quantidade + "@");
                CarrinhoCompra carrinho = new CarrinhoCompra();
                cookie.Value = carrinho.TratarCookieCarrinho(cookie.Value, model);
            }
            else
            {
                cookie = new HttpCookie("CookieCarrinhoLojaKarina");
                cookie.Value = model.IdProduto + "," + model.Quantidade + "@";
            }

            this.ControllerContext.HttpContext.Response.Cookies.Add(cookie);
            CarrinhoCompraObject carrinhoCompraObj = new CarrinhoCompraObject();
            var modelCarinhoCompra = carrinhoCompraObj.ListaCarrinho(cookie.Value);

            CarrinhoCompra carrinhoCompra = new Models.CarrinhoCompra();
            ViewBag.Total = carrinhoCompra.CalculaTotal(modelCarinhoCompra);

            return View(modelCarinhoCompra);
        }

        /// <summary>
        /// Lista de produtos
        /// </summary>
        /// <returns></returns>
        public ActionResult ListaProdutos()
        {
            ProdutosObj produtos = new ProdutosObj();
            var model = produtos.ListaProdutos();
            return View(model);
        }

        /// <summary>
        /// Editar Promoçao do produto
        /// </summary>
        /// <param name="id">Id do produto</param>
        /// <returns></returns>
        public ActionResult EditarPromocao(int id)
        {
            Produtos produto = new Produtos().GetProduto(id);
            var model = produto;
            ViewBag.Produto = produto.Nome;
            return View(model);
        }      
    }
}