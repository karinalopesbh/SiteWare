﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;


namespace SW.Models
{
    class Promocoes
    {
        /// <summary>
        /// Efetua o calculo da promoção
        /// </summary>
        /// <param name="p2"></param>
        /// <param name="valorUnitario"></param>
        /// <returns></returns>
        private decimal LevePague(int p2, decimal valorUnitario)
        {
            decimal valorTotal = 0;

            valorTotal = p2 * valorUnitario;

            return valorTotal;
        }

        /// <summary>
        /// Calcula a promocao leve x e page y
        /// </summary>
        /// <param name="p2"></param>
        /// <param name="valorUnitario"></param>
        /// <returns></returns>
        public decimal ValorTotalProdutoComPromocaoLevePague(int quantidade, int p1, int p2, decimal valorUnitario)
        {
            int quantidadePromocao = Convert.ToInt32(quantidade / p1);
            decimal valorFinal = quantidadePromocao * LevePague(p2, valorUnitario);
            int quantidadeUnitaria = quantidade - (quantidadePromocao * p1);
            valorFinal = valorFinal + (quantidadeUnitaria * valorUnitario);

            return valorFinal;
        }

        /// <summary>
        /// Calcula o valor total do produto na promoção X por Y
        /// </summary>
        /// <param name="quantidade"></param>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <param name="valorUnitario"></param>
        /// <returns></returns>
        public decimal ValorTotalProdutoComPromocaoXporY(int quantidade, int p1, int p2, decimal valorUnitario)
        {
            int quantidadePromocao = Convert.ToInt32(quantidade / p1);
            decimal valorFinal = quantidadePromocao * p2;
            int quantidadeUnitaria = quantidade - (quantidadePromocao * p1);
            valorFinal = valorFinal + (quantidadeUnitaria * valorUnitario);

            return valorFinal;
        }

        /// <summary>
        /// Calcula o subtotal dos produtos no carrinho de compra
        /// </summary>
        /// <param name="idPromocao"></param>
        /// <param name="quantidade"></param>
        /// <param name="valorUnitario"></param>
        /// <returns></returns>
        public decimal CalculaSubTotal(int idPromocao, int quantidade, decimal valorUnitario)
        {
            decimal subTotal = 0;
            BancoDados.BancoDados bd = new BancoDados.BancoDados();

            if (idPromocao != 0)
            {
                DataTable dt = new DataTable();
                string sql = string.Empty;

                sql = string.Format(@"select Parametros, TbPromocao.IdTipo as TipoPromocao
                                from TbPromocao
                                inner join TbTipoPromocao
                                on TbPromocao.IdTipo = TbTipoPromocao.IdTipoPromocao
                                where TbPromocao.IdPromocao = {0}", idPromocao);
                dt = bd.ConsultaSQL(sql);

                string parametros = dt.Rows[0]["Parametros"].ToString();
                string[] lparam = parametros.Split(';');

                List<int> listaparametros = new List<int>();

                foreach (string param in lparam)
                {
                    string[] lparametro = param.Split('=');
                    listaparametros.Add(Convert.ToInt32(lparametro[1]));
                }

                switch (dt.Rows[0]["TipoPromocao"].ToString())
                {
                    // Promoção Leve e Pague
                    case "1":
                        subTotal = ValorTotalProdutoComPromocaoLevePague(quantidade, listaparametros[0], listaparametros[1], valorUnitario);
                        break;
                    // Promoção X por Y
                    case "2":
                        subTotal = ValorTotalProdutoComPromocaoXporY(quantidade, listaparametros[0], listaparametros[1], valorUnitario);
                        break;

                }
            }
            else
            {
                subTotal = quantidade * valorUnitario;
            }

            return subTotal;
        }
    }
}
