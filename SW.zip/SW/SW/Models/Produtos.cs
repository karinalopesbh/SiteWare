﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace SW.Models
{
    public class Produtos
    {
        public int IdProduto { get; set; }
        public string Nome { get; set; }
        public decimal ValorUnidade { get; set; }
        public string Promocao { get; set; }
        public int IdPromocao { get; set; }
        public string Categoria { get; set; }
        public string CaminhoImagem { get; set; }
        public int Quantidade { get; set; }

        BancoDados.BancoDados bd = new BancoDados.BancoDados();

        /// <summary>
        /// Retorna o produto
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public Produtos GetProduto(int Id)
        {
            DataTable dt = new DataTable();
            string sql = string.Empty;

            sql = string.Format(@"select IdProduto, Nome, ValorUnidade, IdPromocao, TbCategoria.Descricao Categoria
                                from TbProduto
                                inner join TbCategoria
                                on TbProduto.IdCategoria = TbCategoria.IdCategoria
                                where IdProduto = {0}", Id);
            dt = bd.ConsultaSQL(sql);

            Produtos produto = new Produtos();
            produto.IdProduto = Id;
            produto.Nome = dt.Rows[0]["Nome"].ToString();
            produto.ValorUnidade = Convert.ToDecimal(dt.Rows[0]["ValorUnidade"].ToString());

            if(string.IsNullOrEmpty(dt.Rows[0]["IdPromocao"].ToString()))
            {
                produto.IdPromocao = 0;
            }
            else
            {
                produto.IdPromocao = Convert.ToInt32(dt.Rows[0]["IdPromocao"].ToString());
            }            

            produto.Promocao = GetPromocao(dt.Rows[0]["IdPromocao"].ToString());
            produto.Categoria = dt.Rows[0]["Categoria"].ToString();
            produto.CaminhoImagem = string.Format("../Content/Images/prd_{0}.png", Id.ToString());

            return produto;
        }

        /// <summary>
        /// Retorna a promoçao do produto
        /// </summary>
        /// <param name="idPromocao">Id da promoçao</param>
        /// <returns>Retorna o nome da promoçao</returns>
        public string GetPromocao(string idPromocao)
        {
            string nomepromocao = string.Empty;
            if (!string.IsNullOrEmpty(idPromocao))
            {
                DataTable dt = new DataTable();
                string sql = string.Empty;

                sql = string.Format(@"select Parametros, TbTipoPromocao.Nome
                                from TbPromocao
                                inner join TbTipoPromocao
                                on TbPromocao.IdTipo = TbTipoPromocao.IdTipoPromocao
                                where TbPromocao.IdPromocao = {0}", idPromocao);
                dt = bd.ConsultaSQL(sql);

                string parametros = dt.Rows[0]["Parametros"].ToString();
                nomepromocao = "Promoçao: " + dt.Rows[0]["Nome"].ToString();
                string[] lparam = parametros.Split(';');

                foreach (string param in lparam)
                {
                    string[] lparametro = param.Split('=');
                    nomepromocao = nomepromocao.Replace(lparametro[0], lparametro[1]);
                }
            }
            return nomepromocao;
        }
    }

    public class ProdutosObj
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();
        string sql = string.Empty;

        /// <summary>
        /// Retorna a lista de produtos
        /// </summary>
        /// <returns></returns>
        public List<Produtos> ListaProdutos()
        {
            List<Produtos> lprodutos = new List<Produtos>();

            DataTable dt = new DataTable();

            sql = @"select IdProduto, Nome, ValorUnidade, IdPromocao
                  from TbProduto";

            dt = bd.ConsultaSQL(sql);

            foreach (DataRow dr in dt.Rows)
            {
                Produtos produto = new Produtos();
                produto.IdProduto = Convert.ToInt32(dr["IdProduto"]);
                produto.Nome = dr["Nome"].ToString();
                produto.ValorUnidade = Convert.ToDecimal(dr["ValorUnidade"]);
                produto.Promocao = produto.GetPromocao(dr["IdPromocao"].ToString());
                produto.CaminhoImagem = string.Format("../Content/Images/prd_{0}.png", produto.IdProduto.ToString());

                lprodutos.Add(produto);
            }

            return lprodutos;
        }
    }
}