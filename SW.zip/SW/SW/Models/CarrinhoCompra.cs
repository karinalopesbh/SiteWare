﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SW.Models
{
    public class CarrinhoCompra
    {
        public Produtos produto;
        public decimal subTotal { get; set; }

        /// <summary>
        /// Calcular o valor total do carrinho
        /// </summary>
        /// <param name="carrinhoCompra"></param>
        /// <returns></returns>
        public decimal CalculaTotal(List<CarrinhoCompra> carrinhoCompra)
        {
            decimal total = 0;

            foreach (CarrinhoCompra carrinho in carrinhoCompra)
            {
                total = carrinho.subTotal + total;
            }

            return total;
        }

        /// <summary>
        /// Trata o cookie ao montar o carrinho de compras
        /// </summary>
        /// <param name="CookieCarrinhoLojaKarina"></param>
        /// <param name="produto"></param>
        /// <returns></returns>
        public string TratarCookieCarrinho(string CookieCarrinhoLojaKarina, Produtos produto)
        {
            string novocookie = string.Empty;

            if (CookieCarrinhoLojaKarina.IndexOf(produto.IdProduto.ToString() + ",") >= 0)
            {              
                string[] lcookie = CookieCarrinhoLojaKarina.Split('@');

                foreach (string param in lcookie)
                {
                    string[] lparam = param.Split(',');

                    if (!string.IsNullOrEmpty(lparam[0]))
                    {
                        if (lparam[0] == produto.IdProduto.ToString())
                        {
                            int quantidade = Convert.ToInt32(lparam[1]);
                            quantidade = quantidade + produto.Quantidade;
                            novocookie = string.Concat(novocookie, produto.IdProduto.ToString(), ",", quantidade, "@");
                        }   
                        else
                        {
                            novocookie = string.Concat(novocookie, lparam[0], ",", lparam[1], "@");
                        }                     
                    }
                }
            }
            else
            {
                novocookie = string.Concat(CookieCarrinhoLojaKarina, produto.IdProduto.ToString(), ",", produto.Quantidade, "@");
            }

            return novocookie;
        }
    }

    public class CarrinhoCompraObject
    {
        /// <summary>
        /// Retorna a lista dos produtos do carrinho de compra
        /// </summary>
        /// <param name="CookieCarrinhoLojaKarina"></param>
        /// <returns></returns>
        public List<CarrinhoCompra> ListaCarrinho(string CookieCarrinhoLojaKarina)
        {
            string[] lcookie = CookieCarrinhoLojaKarina.Split('@');
            List<CarrinhoCompra> lcc = new List<CarrinhoCompra>();

            foreach (string param in lcookie)
            {
                string[] lparam = param.Split(',');

                if (!string.IsNullOrEmpty(lparam[0]))
                {
                    Produtos p = new Produtos();
                    CarrinhoCompra c = new CarrinhoCompra();
                    Promocoes promocoes = new Promocoes();
                    p = p.GetProduto(Convert.ToInt32(lparam[0]));
                    p.Quantidade = Convert.ToInt32(lparam[1]);
                    c.produto = p;

                    c.subTotal = promocoes.CalculaSubTotal(p.IdPromocao, Convert.ToInt32(lparam[1]), p.ValorUnidade);

                    lcc.Add(c);
                }
            }

            return lcc;
        }
    }
}