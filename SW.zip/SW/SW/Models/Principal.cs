﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using BancoDados;

namespace SW.Models
{
    public class Principal
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();

        public int TotalProdutos()
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select count(*)
                                  from TbProduto");

            dt = bd.ConsultaSQL(sql);

            return Convert.ToInt32(dt.Rows[0][0]);
        }

        /*BancoDados.BancoDados bd = new BancoDados.BancoDados();
        BancoDados.Criptografia crip = new BancoDados.Criptografia();

        [Required(ErrorMessage = "O campo Usuário é obrigatório.")]
        [StringLength(50, MinimumLength = 1)]
        public string Usuario { get; set; }

        [Required(ErrorMessage = "O campo Senha é obrigatório.")]
        [StringLength(50, MinimumLength = 1)]
        public string Senha { get; set; }

        public bool UsuarioValido()
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select idusuario, Senha
                                from TbUsuarios
                                where Login = '{0}'", Usuario);

            dt = bd.ConsultaSQL(sql);

            if (dt.Rows.Count > 0)
            {
                string senhaDescriptografada = crip.DescriptografarTexto(dt.Rows[0]["Senha"].ToString());

                if (senhaDescriptografada == Senha)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool UsuarioAdministrador()
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select login
                                  from TbUsuarios
                                  where TipoUsuario = 0 and 
                                  login = '{0}'", Usuario);

            dt = bd.ConsultaSQL(sql);

            return dt.Rows.Count > 0;
        }*/
    }
}