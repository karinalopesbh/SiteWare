﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BancoDados;
using System.Data;

namespace SW.Models
{
    public class DetalhesProduto
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();

        public int IdProduto { get; set; }

        public decimal ValorUnitario(int idProduto)
        {            
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select ValorUnidade
                                  from TbProduto 
                                  where IdProduto = {0}", idProduto);

            dt = bd.ConsultaSQL(sql);

            return Convert.ToDecimal(dt.Rows[0][0]);
        }

        public string NomeProduto(int idProduto)
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select Nome
                                  from TbProduto 
                                  where IdProduto = {0}", idProduto);

            dt = bd.ConsultaSQL(sql);

            return Convert.ToString(dt.Rows[0][0]);
        }

        public string CategoriaProduto(int idProduto)
        {
            string sql = string.Empty;
            DataTable dt = new DataTable();

            sql = string.Format(@"select c.Descricao
                                  from TbProduto p inner join TbCategoria c 
                                  on p.IdCategoria = c.IdCategoria
                                  where IdProduto = {0}", idProduto);

            dt = bd.ConsultaSQL(sql);

            return Convert.ToString(dt.Rows[0][0]);
        }

        /*public string PromocaoProduto()
        {
        }*/

        public string ColocarNoCarrinho()
        {
            /*    cookie = "Yeah - Cookie: " + this.ControllerContext.HttpContext.Request.Cookies["Cookie"].Value;
            
            ViewData["Cookie"] = cookie;*/
            return "a";
        }

        public decimal CalculoCompra()
        {
            decimal valorCompra = 0;

            //identifica produtos
            //verifica se há promoção
            //se houver qual o tipo dela
            //chama função de cálculo do tipo
            //se nao calcula o valor (quantidade * preço)

            return valorCompra;
        }
    }
}
