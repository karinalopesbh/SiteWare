begin tran  

insert into TbTipoPromocao
values ('Leve _p1_ pague _p2_', getdate())
go
insert into TbTipoPromocao
values ('_p1_ por _p2_', getdate())  

--commit
--rollback