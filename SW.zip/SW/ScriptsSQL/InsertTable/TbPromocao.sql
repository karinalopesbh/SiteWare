begin tran
insert into TbPromocao
values (1, '_p1_=3;_p2_=2', getdate())
go
insert into TbPromocao
values (2, '_p1_=2;_p2_=20', getdate())
go
--commit
--rollback