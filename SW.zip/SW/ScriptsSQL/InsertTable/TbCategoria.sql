begin tran
insert into TbCategoria 
values ('Alimento', getdate())
--commit
--rollback