begin tran
insert into TbProduto
values (1,1,'Bombom Sonho de Valsa - 21,5 gramas', 1.10, getdate())
go
insert into TbProduto
values (2,1,'Caixa de Bombom Lacta - 332 gramas', 13.80, getdate())
go
insert into TbProduto
values (null,1,'Caixa de Bombom Garoto - 300 gramas ', 9.50, getdate())
go
insert into TbProduto
values (null,1,'Caixa de Bombom Nestle - 300 gramas ', 12.99, getdate())
go
insert into TbProduto
values (null,1,'Alfajor Turma da Mônica 20 gramas ', 2.99, getdate())
--commit
--rollback