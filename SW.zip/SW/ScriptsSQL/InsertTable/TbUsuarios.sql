begin tran
insert into TbUsuarios 
values (0, 'Admin', 'OqjlsawlJcA=', getdate())
--commit
--rollback