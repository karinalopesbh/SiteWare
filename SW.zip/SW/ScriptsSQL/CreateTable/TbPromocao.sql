create table TbPromocao
(
	IdPromocao int IDENTITY(1,1) not null, --pk
	IdTipo int not null,
	Parametros varchar(30),
	DataCriacao datetime,
	constraint pk_IdPromocao primary key( IdPromocao ),
	constraint fk_IdTipo foreign key( IdTipo ) references TbTipoPromocao( IdTipoPromocao ),
)