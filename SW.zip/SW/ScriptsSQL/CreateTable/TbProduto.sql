create table TbProduto
(
	IdProduto int IDENTITY(1,1) not null, -- pk
	IdPromocao int null, 
	IdCategoria int not null,
	Nome varchar(50),
	ValorUnidade decimal(4,2),
	DataCriacao datetime,
	constraint pk_IdProduto primary key( IdProduto ),
	constraint fk_IdPromocao foreign key( IdPromocao ) references TbPromocao( IdPromocao ),
	constraint fk_IdCategoria foreign key( IdCategoria ) references TbCategoria( IdCategoria ),
)
