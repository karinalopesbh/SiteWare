create table TbTipoPromocao
(
	IdTipoPromocao int IDENTITY(1,1) not null, 
	Nome varchar(30),
	DataCriacao datetime,
	constraint pk_IdTipo primary key( IdTipoPromocao ),
)