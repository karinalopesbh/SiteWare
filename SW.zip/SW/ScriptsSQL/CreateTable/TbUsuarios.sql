create table TbUsuarios
(
	IdUsuario int IDENTITY(1,1) not null, 
	TipoUsuario int not null,
	Login varchar(30),
	Senha varchar(30),	
	DataCriacao datetime,
	constraint pk_IdUsuario primary key( IdUsuario ),
)