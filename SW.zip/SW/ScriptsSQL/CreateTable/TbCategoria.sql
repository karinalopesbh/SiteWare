create table TbCategoria
(
	IdCategoria int IDENTITY(1,1) not null, 
	Descricao varchar(50),
	DataCriacao datetime,
	constraint pk_IdCategoria primary key( IdCategoria ),
)